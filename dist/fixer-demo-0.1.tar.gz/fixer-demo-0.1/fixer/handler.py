def get_rates():
    print("Hello world test")
